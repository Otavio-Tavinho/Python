# 1° Exercício "nome e RGH do aluno"
nome = input("Digite seu nome completo: ")
rgm = int(input("Digite seu RGM: "))
print("Seu nome mais RGM é: ", nome, '/', rgm)
print("-------------")


