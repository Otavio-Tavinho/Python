# 1° Exercício "média do aluno"
nt1 = float(input("Digite a primeira nota: "))
nt2 = float(input("Digite a segunda nota: "))
nt3 = float(input("Digite a terceira nota: "))
nt4 = float(input("Digite a quarta nota: "))
med = (nt1 + nt2 + nt3 + nt4) / 4
print("Sua média é: ", med)
if (med >= 8 and med <= 10):
    print("Conceito (A), Parabéns você foi Aprovado!")
elif (med >= 7 and med < 8):
    print("Conceito (B), Parabéns você foi Aprovado!")
elif (med >= 6 and med < 7):
    print("Conceito (C), Parabéns você foi Aprovado!")
else:
    print("Conceito (D), Você foi Reprovado!")
print("----------------------------------------------")

# 2° Exercício "Forma geométrica"
form = input("Informe o nome do formato geométrico: ")
if form == "Quadrado" or form == "quadrado":
    lad = int(input("Digite o tamanho do lado: "))
    are = lad * lad
    print("Os valores lidos são:", are)
elif form == "Triângulo" or form == "triângulo" or form == "Triangulo" or form == "triangulo":
    bas = int(input("Digite o tamanho da base: "))
    alt = int(input("Digite a altura: "))
    are = bas * alt / 2
    print("Os valores lidos são:", are)
elif form == "Retângulo" or form == "retângulo" or form == "Retangulo" or form == "retangulo":
    bas = int(input("Digite o tamanho da base: "))
    alt = int(input("Digite a altura: "))
    are = bas * alt
    print("Os valores lidos são:", are)
elif form == "Trapézio" or form == "trapézio" or form == "Trapezio" or form == "trapezio":
    basA = int(input("Digite o valor da maior base: "))
    basS = int(input("Digite o valor da menor base: "))
    alt = int(input("Digite o valor da altura: "))
    are = (basA + basS) * alt / 2
    print("Os valores lidos são:", are)
elif form == "Pentágono" or form == "pentágono" or form == "Pentagono" or form == "pentagono":
    lad = int(input("Digite o valor de um lado: "))
    apo = int(input("Digite o valor do apotema: "))
    peri = lad * 5
    are = (peri * apo) / 2
    print("Os valores lidos são:", are)
elif form == "Hexágono" or form == "hexágono" or form == "Hexagono" or form == "hexagono":
    lad = int(input("Digite o tamnaho do lado: "))
    peri = lad * 6
    are = peri
    print("Os valores lidos são:", are)
else:
    print("Informe o valor correto!")
print("----------------------------------------------")

# 3° Exercício "Salário funcionário"
at = int(input("Digite os anos trabalhados: "))
sl = int(input("Digite o valor do seu salário: "))
rj = sl * 0.3
nsl = sl + rj
if (at > 5) and (sl >= 1320 and sl <= 2640):
    print("Seu salário teve um reajuste de:",rj, "e seu salário reajustado é:",nsl)
else:
    at <= 5
    rj = float(input("Informe a porcentagem de reajuste: "))
    rj = sl * rj
    nsl = sl + rj
    print("Seu salário teve um reajuste de: ", rj, "e seu salário reajustado é: ", nsl)
print("----------------------------------------------")

# 4° Exercício "Conversor de temperatura"
con = input("Informe o nome da escala para fazer a conversão da temperatura: ")
if con == "Celsius" or con == "celsius":
    c = float(input(" Digite o valor da temperatura em grau Celsius: "))
    f = ((c * 9) / 5) + 32
    k = c + 273
    print("A temperatura em Celsius para Fahrenheit é:",f)
    print("A temperatura em Celsius para Kelvin é:", k)
elif con == "Fahrenheit" or con == "fahrenheit":
    f = float(input("Digite o valor da temperatura em grau Fahrenheit: "))
    c = ((f - 32) * 5) / 9
    k = (((f - 32) * 5) / 9) + 273
    print("A temperatura em Fahrenheit para Celsius é:",c)
    print("A temperatura em Fahrenheit para Kelvin é:",k)
elif con == "Kelvin" or con == "kelvin":
    k = float(input("Digite o valor da temperatura em grau Kelvin: "))
    c = k - 273
    f = (((k - 273) * 5) / 9) + 32
    print("A temperatura em Kelvin para Celsius é:",c)
    print("A temperatura em Kelvin para Fahrenheit é:",f)
else:
    print("Informe o nome da escala para conversão correto!")