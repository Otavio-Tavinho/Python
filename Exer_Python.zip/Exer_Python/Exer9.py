# Josúe Pereira RGM: 134247408
# Otávio da Silva Moreira RGM: 134560637

# Atividade 3°.

import math

def lin():
    print("-" * 50)


opc = 0
opc += 1
while opc != 5:
    lin()
    print("                     MENU")
    lin()
    print('''        [A] Raiz Quadrada
        [B] Raiz Cúbica
        [C] Quadrado do Número
        [D] Cubo do Número
        [E] Sair''')
    lin()
    opc = input("Digite a opção desejada: ")
    lin()
    try:
        if opc == "A" or opc == "a":
            num = int(input("Insira um valor: "))
            calc = math.sqrt(num)
            print("O resultado da Raiz Quadrada é:{:.2f}".format(calc))
        elif opc == "B" or opc == "b":
            num = int(input("Insira um valor: "))
            calc = math.pow(num, 1/3)
            print("O resultado da Raiz Cúbica é: {:.2f}".format(calc))
        elif opc == "C" or opc == "c":
            num = int(input("Insira um valor: "))
            calc = math.pow(num, 2)
            print("O resultado do Quadrado de um Número é:{:.2f}".format(calc))
        elif opc == "D" or opc == "d":
            num = int(input("Insira um valor: "))
            calc = math.pow(num, 3)
            print("O resultado do Cubo de um Número é:{:.2f}".format(calc))
        elif opc == "E" or opc == "e":
            print("Saindo do programa...")
            print("Programa encerado!")
            break
        else:
            print("Digite uma opção valida")
    except ValueError:
        print("Insira somente algarismo igual ou maiores que Zero!")