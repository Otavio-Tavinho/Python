import math
import traceback

def lin():
    print("-" * 50)

try:
    opc = 0
    opc += 1
    while opc != 5:
        lin()
        print("                  MENU      ")
        lin()
        print('''        [ 1 ] Calcular Cubo
        [ 2 ] Calcular Watts 
        [ 3 ] Calcular Calórias do Alimento
        [ 4 ] Calcular Pentagono
        [ 5 ] Encerrar programa''')
        lin()
        opc = int(input("Escolha a opção desejada para fazer a conversão: "))
        if opc == 1:
            aresta = float(input("Digite o valor da aresta: "))
            are = math.pow(aresta, 2) * 6
            print("A area de um cubo é de: {}".format(are))
        elif opc == 2:
            wat = float(input("Informe o valor do watts: "))
            qwat = wat * 0.001
            print("O valor digitado em quilowatt é: {}".format(qwat))
        elif opc == 3:
            kcal = float(input("Informe o valor do alimento em kcal: "))
            cal = kcal * 0.001
            print("O valor digitado em calórias é : {}".format(cal))
        elif opc == 4:
            lad = float(input("Digite o valor de um lado: "))
            apo = float(input("Digite o valor do apotema: "))
            peri = lad * 5
            are = (peri * apo) / 2
            print("Os valores lidos são: {}".format(are))
        else:
            print("Encerrando o programa....")
            print("Programa encerrado, Obrigado!")
except NameError:
    print("Opção invalida, tente novamente depois.")
except ValueError:
    print("Opção invalida, tente novamente depois.")