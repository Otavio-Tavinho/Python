# 1° Exercício "média ponderada"
p1 = 2
p2 = 3
p3 = 5
nt1 = float(input("Digite a primeira nota: "))
nt2 = float(input("Digite a segunda nota: "))
nt3 = float(input("Digite a terceira nota: "))
med = (nt1 * p1) + (nt2 * p2) + (nt3 * p3) / 10
print("Sua nota foi calculada, sua média ponderada é: ", med)
print("-----------------------------------------------------")

# 2° Exercício "Salário líquido"
ht = float(input("Digite as horas trabalhadas: "))
vh = float(input("Digite o valor da horas trabalhadas: "))
pd = vh * 0.2
sb = ht * vh
td = (pd / 100) * sb
sl = sb - td
print("Horas trabalhadas: ", ht)
print("Salário Bruto: ", sb)
print("Desconto total: ", td)
print("Salário a receber: ", sl)
print("------------------------")

# 3° Exercício "Temperatura"
f = float(input("Digite a temperatura em Fahrenheit: "))
c = ((f - 32) * 5) / 9
print("A temperatura digitada em Fahrenheit de", f, "corresponde a", c, "em grau Celsius!")
print("----------------------------------------------------------------------------------")

# 4° Exercício "Tamanho do quadrado"
print("(a + b)² = a² + 2ab + b²")
a = int(input("Digite o valor de A: "))
b = int(input("Digite o valor de B: "))
lado = (a * a) + (b * b)
area = 2 * a * b
soma = lado + area # ou soma = (a * a) + (b * b) + (2 * a * b)
print("Os valores lidos são: ", soma)


