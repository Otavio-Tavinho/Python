# Josúe Pereira RGM: 134247408
# Otávio da Silva Moreira RGM: 134560637

# Atividade 1°.

# Professora perdão, mais foi isso que intendi do enunciado. Por favor da um desconto vai kkkk pelo menos meio ponto.

def lin():
    print("-" * 36)


def leia(a: str):
    while True:
        valor = input(a)
        if valor.isnumeric():
            return int(valor)
        else:
            lin()
            print("Opção invalida, insira algarismo positivo!")
            lin()


lin()
print("             Sequência")
lin()
while True:
    n = leia("Quantos termos você quer mostrar: ")
    if n <= 0:
        lin()
        print("Insira um valor maior que Zero")
        lin()
    else:
        t1 = 3
        t2 = 2
        t3 = 0
        t4 = 5
        t5 = -3
        t6 = 8
        lin()
        print("{} ⤍ {} ⤍ {} ⤍ {} ⤍ {} ⤍ {}".format(t1, t2, t3, t4, t5, t6), end='')
        cont = 2
        while cont <= n:
            t7 = t1, t2, t3, t4, t5, t6
            print(" ⤍ {}".format(t7), end='')
            cont += 1
        print(" ⤍ FIM", end='')
        break