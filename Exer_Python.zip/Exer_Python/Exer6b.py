#Exercício 1 "Média Aluno"

import traceback

def lin():
    print("-" * 50)

try:
    n1 = float(input("Digite a primeira nota: "))
    n2 = float(input("Digite a segunda nota: "))
    n3 = float(input("Digite a terceira nota: "))
    n4 = float(input("Digite a quarta nota: "))
    med = (n1 + n2 + n3 + n4) / 4
    lin()
    print("Sua média é: {:.2f}".format(med))
    lin()
    if med >= 7 and med <= 10:
        print("Parabéns você foi aprovado!")
        lin()
    elif med >= 4 and med < 7:
        print("Atenção, você está de exame!")
        lin()
    else:
        print("Reprovado, você precisa estudar mais.")
        lin()
except NameError:
    print("Informe a nota corretamente!")
except ValueError:
    print("Informe a nota corretamente!")
    lin()


#Exercício 2 "Conversor"

try:
    opc = 0
    opc += 1
    while opc != 3:
        print("                  MENU      ")
        lin()
        print('''        [ 1 ] Kcal em Calórias
        [ 2 ] Calórias em Kcal 
        [ 3 ] Encerrar programa''')
        lin()
        opc = int(input("Escola a opção desejada para fazer a conversão: "))
        if opc == 1:
            num1 = float(input("Informe o valor: "))
            cal = (num1 * 4.18) * 1000
            print("O valor digitado em calórias é : {}".format(cal))
            lin()
        elif opc == 2:
            num2 = float(input("Informe o valor: "))
            kcal = num2 * 1000
            print("O valor digitado em kcal é: {}".format(kcal))
            lin()
        else:
            print("Encerrando o programa....")
            print("Programa encerrado, Obrigado!")
            lin()
except NameError:
    print("Opção invalida, tente novamente depois.")
except ValueError:
    print("Opção invalida, tente novamente depois.")