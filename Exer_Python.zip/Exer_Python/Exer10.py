# Josúe Pereira RGM: 134247408
# Otávio da Silva Moreira RGM: 134560637

# Atividade 2°.

from random import randint

def lin():
    print("-" * 40)


def leia(a: str):
    while True:
        valor = input(a)
        if valor.isnumeric():
            return int(valor)
        else:
            lin()
            print("Opção invalida, insira algarismo positivo!")
            lin()


num = (randint(0, 20))
rand = 21
sort = 0
sort += 1
while num != sort:
    lin()
    rand = leia("Tente a Sorte, insira o número sorteado: ")
    lin()
    if rand < num:
        print("Quase lá, insira um valor maior!")
    elif rand > num:
        print("Quase lá, insira um valor menor!")
    else:
        print("Parabéns você acertou!")
        break
