# Josúe Pereira RGM: 134247408
# Otávio da Silva Moreira RGM: 134560637

# Atividade de calculadora binária.

def lin():
    print("-" * 50)


def leia(a: str):
    while True:
        valor = input(a)
        if valor.isnumeric():
            return int(valor)
        else:
            lin()
            print("Opção invalida, tente de novo!")
            lin()


opc = 0
opc += 1
while opc != 5:
    lin()
    print("                     MENU")
    lin()
    print('''        [1] Adição
        [2] Subtração 
        [3] Divisão
        [4] Multiplicação
        [5] Encerrar programa''')
    lin()
    opc = leia("Digite a opção desejada: ")
    lin()
    try:
        if opc == 1:
            num1 = input("Insira o primeiro valor: ")
            num2 = input("Insira o segundo valor: ")
            calc = int(num1, 2) + int(num2, 2)
            print(f"O resultado em binário é: {bin(calc)}")
        elif opc == 2:
            num1 = input("Insira o primeiro valor: ")
            num2 = input("Insira o segundo valor: ")
            calc = int(num1, 2) - int(num2, 2)
            print(f"O resultado em binário é: {bin(calc)}")
        elif opc == 3:
            num1 = input("Insira o primeiro valor: ")
            num2 = input("Insira o segundo valor: ")
            calc = int(num1, 2) // int(num2, 2)
            if calc != 0:
                print(f"O resultado em binário é: {bin(calc)}")
            else:
                print("Insira dividendo maior que '0'.")
        elif opc == 4:
            num1 = input("Insira o primeiro valor: ")
            num2 = input("Insira o segundo valor: ")
            calc = int(num1, 2) * int(num2, 2)
            print(f"O resultado em binário é: {bin(calc)}")
        elif opc == 5:
            print("Encerrando programa...")
            print("Programa encerado!")
        else:
            print("Digite uma opção valida")
    except ZeroDivisionError:
        print("Divisões por 'Zero' é coisa de louco!")
    except ValueError:
        print("O calculo sera feito ao digitar algarismo binário!")