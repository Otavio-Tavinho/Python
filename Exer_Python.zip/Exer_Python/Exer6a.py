# Exercício 2 "IMC"

def lin():
    print("-" * 30)

import math

def imc():

    pes = float(input("Digite o seu peso: "))
    alt = float(input("Digite a sua altura: "))
    imc = pes / (math.pow (alt, 2))
    print("O IMC é: {:.1f}". format(imc))

    if imc < 17:
        print("A baixo do peso!")
    elif imc > 18 and imc < 25:\
        print("Peso normal!")
    elif imc > 25 and imc < 30:\
        print("Acima do peso!")
    elif imc > 30 and imc < 35:\
        print("Obesidade nivel 1")
    elif imc > 35 and  imc < 40:\
        print("Obesidade  nivel 2")
    else:
        print("Obesidade nivel 3")

imc()
lin()

# Exercício 3 "Cilindro"

import math

r = float(input("Digite o valor do raio: "))
h = float(input("Digite o valor da altura: "))
are = math.pi * (math.pow(r, 2))
vol = math.pi * (math.pow(r, 2)) * h
print("A area base é de {:.2f} já o volume é de {:.2f}".format(are, vol))
lin()