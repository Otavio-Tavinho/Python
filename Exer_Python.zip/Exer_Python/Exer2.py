# 1° Exercício "média do aluno"
nt1 = float(input("Digite a primeira nota: "))
nt2 = float(input("Digite a segunda nota: "))
nt3 = float(input("Digite a terceira nota: "))
nt4 = float(input("Digite a quarta nota: "))
med = (nt1 + nt2 + nt3 + nt4) / 4
print("Sua nota foi calculada, sua média é: ", med)
print("-------------")

# 2° Exercício "lado do quadrado"
print("valor da área e perímetro do quadrado")
lad = int(input("Digite um lado do quadrado: "))
peri = lad * 4
are = lad * lad
print("Perimetro", peri)
print("Area", are)
